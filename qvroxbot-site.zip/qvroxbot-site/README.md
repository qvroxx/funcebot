# QvroxBOT Site

Sıfırdan hazırlanmış, responsive Discord bot landing page. Verilen eren.si/tr sitesinin genel sayfa yapısı ve koyu/modern görsel yaklaşımından esinlenir; kod özgündür.

`index.html` içindeki `href="#"` bağlantılarını gerçek Discord OAuth2 davet ve panel adreslerinle değiştir.
